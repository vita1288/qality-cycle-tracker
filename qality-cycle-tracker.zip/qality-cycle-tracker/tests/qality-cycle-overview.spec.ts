/**
 * QAlity Plus – Test cycle overview, filtered to one assignee.
 *
 * Pulls a test cycle from the QAlity Plus REST API, keeps only executions assigned
 * to the given Jira user, resolves Jira keys/summaries, and produces a summary
 * (console, Markdown report, and reports/qality-dashboard.html).
 *
 * Run: npm test   (reads .env)
 * The test is skipped when QALITY_TOKEN is not set.
 *
 * Required env vars:
 *   QALITY_TOKEN     QAlity Plus API token (Jira → Apps → QAlity Plus API Tokens)
 *   JIRA_EMAIL       your Atlassian account email
 *   JIRA_API_TOKEN   Atlassian API token (id.atlassian.com → Security → API tokens)
 *   JIRA_BASE_URL    e.g. https://your-site.atlassian.net
 *   ASSIGNEE_NAME    Jira display name of the tester
 * Optional:
 *   QALITY_CYCLE_NAME    cycle to report, found by name (default: SPRINT_FILTER, e.g. "Sprint 24").
 *                        Change SPRINT_FILTER each sprint — no ID needed.
 *   QALITY_CYCLE_ID      optional: force one cycle by ID (overrides the name lookup)
 *   ASSIGNEE_ACCOUNT_ID  skip the name lookup and use this Jira accountId directly
 *   QALITY_APP_PATH      Jira app path of QAlity Plus on your site (for "open cycle" links)
 *   FAIL_ON_FAILED       "true" → test fails if any of your executions are Failed
 */
import { test, expect, request, APIRequestContext } from '@playwright/test';
import fs from 'node:fs';
import path from 'node:path';
import { renderQalityDashboard, type QalityHistoryEntry } from '../src/qality-dashboard';

const QALITY_BASE = 'https://apps-qalityplus.soldevelo.com';
const JIRA_BASE = process.env.JIRA_BASE_URL ?? '';
// Set in beforeAll: QALITY_CYCLE_ID if given, otherwise looked up by QALITY_CYCLE_NAME / SPRINT_FILTER.
let CYCLE_ID = Number(process.env.QALITY_CYCLE_ID || 0);
const CYCLE_NAME = (process.env.QALITY_CYCLE_NAME || process.env.SPRINT_FILTER || '').trim();
const ASSIGNEE_NAME = process.env.ASSIGNEE_NAME ?? 'QA Tester';
const QALITY_APP_PATH = process.env.QALITY_APP_PATH ?? '/jira/apps/<app-id>/<environment-id>';

type Status = { id?: number; name?: string; category?: 'FINISHED' | 'UNFINISHED' | 'FAILED' | 'PASSED' };
type CycleCase = {
  id: number; // testCaseInCycleId
  testCaseId: number; // Jira issue id
  statusDetail?: Status;
  testExecution?: { id: number; executionAssignee?: string; comment?: string; statusObject?: Status } | null;
};
type Cycle = { id: number; name: string; isClosed?: boolean; testCases?: CycleCase[]; testCasesTotalPages?: number };
type Row = { key: string; summary: string; status: string; category: string; executionId?: number };

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing environment variable: ${name}`);
  return value;
}

async function getJson<T>(api: APIRequestContext, url: string, params?: Record<string, string | number | boolean>): Promise<T> {
  const res = await api.get(url, { params });
  if (!res.ok()) throw new Error(`GET ${url} → ${res.status()} ${await res.text()}`);
  return (await res.json()) as T;
}

async function resolveAccountId(jira: APIRequestContext): Promise<string> {
  if (process.env.ASSIGNEE_ACCOUNT_ID) return process.env.ASSIGNEE_ACCOUNT_ID;
  const users = await getJson<Array<{ accountId: string; displayName?: string; accountType?: string }>>(
    jira, '/rest/api/3/user/search', { query: ASSIGNEE_NAME, maxResults: 50 },
  );
  const needle = ASSIGNEE_NAME.toLowerCase();
  const matches = users.filter(
    (u) => u.accountType === 'atlassian' && (u.displayName ?? '').toLowerCase().includes(needle),
  );
  if (matches.length !== 1) {
    const found = matches.map((u) => `${u.displayName} (${u.accountId})`).join(', ') || 'none';
    throw new Error(
      `Expected exactly 1 Jira user matching "${ASSIGNEE_NAME}", found ${matches.length}: ${found}. ` +
        'Set ASSIGNEE_ACCOUNT_ID to pick one.',
    );
  }
  return matches[0].accountId;
}

/**
 * Find the test cycle for CYCLE_NAME (e.g. "Sprint 24" → cycle "Sprint - 24").
 * Matching ignores case, dashes/punctuation and the word "Sprint", so the Jira sprint name works as-is.
 * Prefers an exact match, then an open cycle, then the newest.
 */
async function resolveCycleId(qality: APIRequestContext): Promise<number> {
  if (CYCLE_ID) return CYCLE_ID;
  if (!CYCLE_NAME) throw new Error('Set QALITY_CYCLE_NAME (or SPRINT_FILTER), e.g. "Sprint 24", or QALITY_CYCLE_ID');
  type Found = { id: number; name: string; isClosed?: boolean; createdDate?: string };
  const words = (t: string) => t.toLowerCase().replace(/[^a-z0-9]+/g, ' ').split(' ').filter((w) => w && w !== 'sprint');
  const want = words(CYCLE_NAME);
  // The API's name filter is a plain text match, so search by the most specific word (the month) and filter here.
  const term = [...want].filter((w) => !/^\d+$/.test(w)).sort((a, b) => b.length - a.length)[0] ?? want[0];
  const found: Found[] = [];
  for (let page = 0; page < 20; page++) {
    const res = await getJson<{ content?: Found[]; totalPages?: number }>(qality, '/api/testCycles', {
      name: term, page, size: 50, sort: 'createdDate,DESC',
    });
    found.push(...(res.content ?? []));
    if (page + 1 >= (res.totalPages ?? 1)) break;
  }
  const hits = found.filter((c) => { const w = words(c.name ?? ''); return want.every((x) => w.includes(x)); });
  if (!hits.length) {
    const seen = found.slice(0, 10).map((c) => `"${c.name}" (${c.id})`).join(', ') || 'none';
    throw new Error(`No QAlity test cycle matches "${CYCLE_NAME}". Cycles containing "${term}": ${seen}. Set QALITY_CYCLE_NAME or QALITY_CYCLE_ID.`);
  }
  const exact = (c: Found) => Number(words(c.name).join(' ') === want.join(' '));
  hits.sort((a, b) => exact(b) - exact(a) || Number(!!a.isClosed) - Number(!!b.isClosed) || (b.createdDate ?? '').localeCompare(a.createdDate ?? ''));
  if (hits.length > 1) console.log(`QAlity: ${hits.length} cycles match "${CYCLE_NAME}": ${hits.map((c) => `${c.name} (${c.id})`).join(', ')} — using the first`);
  console.log(`QAlity: cycle "${hits[0].name}" (${hits[0].id})`);
  return hits[0].id;
}

async function fetchCycle(qality: APIRequestContext): Promise<Cycle> {
  const first = await getJson<Cycle>(qality, `/api/testCycles/${CYCLE_ID}`, { page: 0 });
  const testCases = [...(first.testCases ?? [])];
  for (let page = 1; page < (first.testCasesTotalPages ?? 1); page++) {
    const next = await getJson<Cycle>(qality, `/api/testCycles/${CYCLE_ID}`, { page });
    testCases.push(...(next.testCases ?? []));
  }
  return { ...first, testCases };
}

async function fetchIssues(jira: APIRequestContext, ids: number[]) {
  const map = new Map<number, { key: string; summary: string }>();
  for (let i = 0; i < ids.length; i += 100) {
    const chunk = ids.slice(i, i + 100);
    const res = await jira.post('/rest/api/3/search/jql', {
      data: { jql: `id in (${chunk.join(',')})`, fields: ['summary'], maxResults: 100 },
    });
    if (!res.ok()) throw new Error(`Jira search → ${res.status()} ${await res.text()}`);
    const body = (await res.json()) as { issues?: Array<{ id: string; key: string; fields?: { summary?: string } }> };
    for (const issue of body.issues ?? []) {
      map.set(Number(issue.id), { key: issue.key, summary: issue.fields?.summary ?? '' });
    }
  }
  return map;
}

function countBy<T>(items: T[], keyOf: (item: T) => string): Record<string, number> {
  return items.reduce<Record<string, number>>((acc, item) => {
    const k = keyOf(item);
    acc[k] = (acc[k] ?? 0) + 1;
    return acc;
  }, {});
}

test.describe(`QAlity Plus – ${CYCLE_ID ? `cycle ${CYCLE_ID}` : CYCLE_NAME || 'cycle'} overview (${ASSIGNEE_NAME})`, () => {
  test.skip(!process.env.QALITY_TOKEN, 'QALITY_TOKEN not set — add it to .env to run the QAlity cycle overview');

  let qality: APIRequestContext;
  let jira: APIRequestContext;

  test.beforeAll(async () => {
    requireEnv('JIRA_BASE_URL');
    qality = await request.newContext({
      baseURL: QALITY_BASE,
      extraHTTPHeaders: { Authorization: `Bearer ${requireEnv('QALITY_TOKEN')}`, Accept: 'application/json' },
    });
    const basic = Buffer.from(`${requireEnv('JIRA_EMAIL')}:${requireEnv('JIRA_API_TOKEN')}`).toString('base64');
    jira = await request.newContext({
      baseURL: JIRA_BASE,
      extraHTTPHeaders: { Authorization: `Basic ${basic}`, Accept: 'application/json' },
    });
  });

  test.afterAll(async () => {
    await qality?.dispose();
    await jira?.dispose();
  });

  test(`executions assigned to ${ASSIGNEE_NAME}`, async ({}, testInfo) => {
    const accountId = await test.step(`Resolve Jira account for "${ASSIGNEE_NAME}"`, () => resolveAccountId(jira));
    CYCLE_ID = await test.step(`Find test cycle ${CYCLE_ID || `"${CYCLE_NAME}"`}`, () => resolveCycleId(qality));
    const cycle = await test.step(`Fetch test cycle ${CYCLE_ID}`, () => fetchCycle(qality));

    const allCases = cycle.testCases ?? [];
    const mine = allCases.filter((tc) => tc.testExecution?.executionAssignee === accountId);
    const unassigned = allCases.filter((tc) => !tc.testExecution?.executionAssignee).length;

    expect(mine.length, `No executions in "${cycle.name}" are assigned to ${ASSIGNEE_NAME} (${accountId})`).toBeGreaterThan(0);

    const issues = await test.step('Resolve Jira keys', () => fetchIssues(jira, mine.map((tc) => tc.testCaseId)));

    const rows: Row[] = mine
      .map((tc) => {
        const status = tc.testExecution?.statusObject ?? tc.statusDetail;
        const issue = issues.get(tc.testCaseId);
        return {
          key: issue?.key ?? String(tc.testCaseId),
          summary: issue?.summary ?? '',
          status: status?.name ?? 'Unexecuted',
          category: status?.category ?? 'UNFINISHED',
          executionId: tc.testExecution?.id,
        };
      })
      .sort((a, b) => a.key.localeCompare(b.key, undefined, { numeric: true }));

    const total = rows.length;
    const executed = rows.filter((r) => r.category !== 'UNFINISHED').length;
    const passed = rows.filter((r) => r.category === 'PASSED').length;
    const failedRows = rows.filter((r) => r.category === 'FAILED');
    const byStatus = countBy(rows, (r) => r.status);
    const pct = (n: number) => `${((n / total) * 100).toFixed(1)}%`;
    const cycleUrl = `${JIRA_BASE}${QALITY_APP_PATH}/test-cycle-details#!testCycleId=${CYCLE_ID}`;

    // Console output
    console.log(`\n${cycle.name} (cycle ${CYCLE_ID}) — ${ASSIGNEE_NAME}`);
    console.log(`Cycle total: ${allCases.length} cases · unassigned: ${unassigned} · ${cycle.isClosed ? 'closed' : 'open'}`);
    console.table({
      Assigned: { count: total, pct: '100%' },
      Executed: { count: executed, pct: pct(executed) },
      Passed: { count: passed, pct: pct(passed) },
      Failed: { count: failedRows.length, pct: pct(failedRows.length) },
    });
    console.table(byStatus);
    console.table(rows.map(({ key, status, summary }) => ({ key, status, summary })));

    // Markdown report
    const esc = (s: string) => s.replace(/\|/g, '\\|');
    const md = [
      `# ${cycle.name} — ${ASSIGNEE_NAME}`,
      '',
      `Cycle: [${CYCLE_ID}](${cycleUrl}) · ${cycle.isClosed ? 'Closed' : 'Open'} · Generated ${new Date().toISOString()}`,
      `Cycle total: ${allCases.length} cases · unassigned: ${unassigned}`,
      '',
      '| Metric | Count | % |',
      '|---|---:|---:|',
      `| Assigned to ${ASSIGNEE_NAME} | ${total} | 100% |`,
      `| Executed | ${executed} | ${pct(executed)} |`,
      `| Passed | ${passed} | ${pct(passed)} |`,
      `| Failed | ${failedRows.length} | ${pct(failedRows.length)} |`,
      '',
      '## By status',
      '',
      '| Status | Count |',
      '|---|---:|',
      ...Object.entries(byStatus).map(([s, n]) => `| ${esc(s)} | ${n} |`),
      '',
      '## Test cases',
      '',
      '| Key | Status | Summary |',
      '|---|---|---|',
      ...rows.map((r) => `| [${r.key}](${JIRA_BASE}/browse/${r.key}) | ${esc(r.status)} | ${esc(r.summary)} |`),
      '',
    ].join('\n');

    const outDir = path.join(process.cwd(), 'reports');
    fs.mkdirSync(outDir, { recursive: true });
    const outFile = path.join(outDir, `cycle-${CYCLE_ID}-${ASSIGNEE_NAME.toLowerCase()}.md`);
    fs.writeFileSync(outFile, md);

    // Dashboard + run history
    const histFile = path.join(outDir, 'qality-history.json');
    let history: QalityHistoryEntry[] = [];
    try { history = JSON.parse(fs.readFileSync(histFile, 'utf8')); } catch { /* first run */ }
    history.push({ at: new Date().toISOString(), cycleId: CYCLE_ID, total, executed, passed, failed: failedRows.length });
    history = history.slice(-200);
    fs.writeFileSync(histFile, JSON.stringify(history, null, 2));

    const html = renderQalityDashboard({
      cycle: { id: CYCLE_ID, name: cycle.name, isClosed: cycle.isClosed, url: cycleUrl },
      assignee: ASSIGNEE_NAME,
      cycleTotal: allCases.length,
      unassigned,
      rows,
      jiraBase: JIRA_BASE,
      history,
      generatedAt: new Date(),
    });
    const dashFile = path.join(outDir, 'qality-dashboard.html');
    fs.writeFileSync(dashFile, html);
    console.log(`\nQAlity dashboard: ${dashFile}`);
    await testInfo.attach('qality-dashboard.html', { body: html, contentType: 'text/html' });

    await testInfo.attach('cycle-overview.md', { body: md, contentType: 'text/markdown' });
    await testInfo.attach('cycle-overview.json', {
      body: JSON.stringify({ cycle: { id: cycle.id, name: cycle.name, isClosed: cycle.isClosed }, assignee: { name: ASSIGNEE_NAME, accountId }, total, executed, passed, failed: failedRows.length, byStatus, rows }, null, 2),
      contentType: 'application/json',
    });

    if (process.env.FAIL_ON_FAILED === 'true') {
      expect(failedRows.map((r) => r.key), 'Failed executions assigned to you').toEqual([]);
    }
  });
});
