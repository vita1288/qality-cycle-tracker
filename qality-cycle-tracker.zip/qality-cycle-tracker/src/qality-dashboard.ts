/**
 * QAlity Plus cycle dashboard — standalone HTML report (light/dark, teal accent).
 */

export type QalityRow = {
  key: string;
  summary: string;
  status: string;
  category: string; // PASSED | FAILED | UNFINISHED | FINISHED
  executionId?: number;
};

export type QalityHistoryEntry = {
  at: string;
  cycleId: number;
  total: number;
  executed: number;
  passed: number;
  failed: number;
};

export type QalityDashboardInput = {
  cycle: { id: number; name: string; isClosed?: boolean; url: string };
  assignee: string;
  cycleTotal: number;
  unassigned: number;
  rows: QalityRow[];
  jiraBase: string;
  history: QalityHistoryEntry[];
  generatedAt: Date;
};

const esc = (s: string) =>
  s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'unknown';

/** "[HDL][Withdrawal] Verify that … [FUN][+]" → module "HDL · Withdrawal", type "FUN", title "Verify that …" */
export function parseSummary(summary: string) {
  let rest = summary.trim();
  const lead: string[] = [];
  let m: RegExpMatchArray | null;
  while ((m = rest.match(/^\[([^\]]+)\]\s*/))) {
    lead.push(m[1].trim());
    rest = rest.slice(m[0].length);
  }
  const trail: string[] = [];
  while ((m = rest.match(/\s*\[([^\]]+)\]$/))) {
    trail.unshift(m[1].trim());
    rest = rest.slice(0, rest.length - m[0].length);
  }
  const types = trail.filter((t) => t !== '+');
  return {
    module: lead.length ? lead.join(' · ') : 'Other',
    type: types[0] ?? 'Untagged',
    title: rest.trim() || summary,
  };
}

// Status display order + colour class (falls back to "muted" for custom statuses)
const TONE: Record<string, string> = {
  failed: 'bad',
  blocked: 'warn',
  'in-progress': 'info',
  unexecuted: 'muted',
  passed: 'ok',
};
const ORDER = ['failed', 'blocked', 'in-progress', 'unexecuted', 'passed'];
const toneOf = (status: string) => TONE[slug(status)] ?? 'muted';
const rank = (status: string) => {
  const i = ORDER.indexOf(slug(status));
  return i === -1 ? ORDER.length - 1 : i;
};

export function renderQalityDashboard(d: QalityDashboardInput): string {
  const rows = d.rows.map((r) => ({ ...r, ...parseSummary(r.summary) }));
  const total = rows.length;
  const executed = rows.filter((r) => r.category !== 'UNFINISHED').length;
  const passed = rows.filter((r) => r.category === 'PASSED').length;
  const failed = rows.filter((r) => r.category === 'FAILED').length;
  const pct = (n: number, of = total) => (of ? Math.round((n / of) * 1000) / 10 : 0);

  // Status counts, ordered for the ring + legend + filters
  const statusCounts = new Map<string, number>();
  for (const r of rows) statusCounts.set(r.status, (statusCounts.get(r.status) ?? 0) + 1);
  const statuses = [...statusCounts.entries()].sort((a, b) => rank(a[0]) - rank(b[0]));

  // Donut ring (circumference-based dash segments)
  const R = 54;
  const C = 2 * Math.PI * R;
  let offset = 0;
  const ring = statuses
    .map(([name, n]) => {
      const len = (n / Math.max(total, 1)) * C;
      const seg = `<circle r="${R}" cx="70" cy="70" fill="none" class="seg ${toneOf(name)}" stroke-width="16"
        stroke-dasharray="${len.toFixed(2)} ${(C - len).toFixed(2)}" stroke-dashoffset="${(-offset).toFixed(2)}"><title>${esc(name)}: ${n}</title></circle>`;
      offset += len;
      return seg;
    })
    .join('');

  // Module + type breakdowns
  const group = (keyOf: (r: (typeof rows)[number]) => string) => {
    const map = new Map<string, { total: number; passed: number; open: number }>();
    for (const r of rows) {
      const k = keyOf(r);
      const g = map.get(k) ?? { total: 0, passed: 0, open: 0 };
      g.total++;
      if (r.category === 'PASSED') g.passed++;
      else g.open++;
      map.set(k, g);
    }
    return [...map.entries()].sort((a, b) => b[1].open - a[1].open || b[1].total - a[1].total);
  };
  const modules = group((r) => r.module);
  const types = group((r) => r.type);
  const maxModule = Math.max(1, ...modules.map(([, g]) => g.total));

  // Share of the whole cycle
  const others = Math.max(d.cycleTotal - total - d.unassigned, 0);

  // History sparkline (this cycle only)
  const hist = d.history.filter((h) => h.cycleId === d.cycle.id).slice(-30);
  const sparkPts = hist
    .map((h, i) => `${hist.length === 1 ? 50 : (i / (hist.length - 1)) * 100},${30 - (pct(h.executed, h.total) / 100) * 28}`)
    .join(' ');
  const prev = hist.length > 1 ? hist[hist.length - 2] : undefined;
  const delta = prev ? executed - prev.executed : 0;

  const attention = rows.filter((r) => r.category !== 'PASSED').sort((a, b) => rank(a.status) - rank(b.status));
  const sorted = [...rows].sort((a, b) => rank(a.status) - rank(b.status) || a.key.localeCompare(b.key, undefined, { numeric: true }));

  const tr = sorted
    .map(
      (r) => `<tr data-status="${slug(r.status)}" data-module="${esc(r.module)}" data-text="${esc(`${r.key} ${r.summary}`.toLowerCase())}">
  <td class="key"><a href="${esc(`${d.jiraBase}/browse/${r.key}`)}" target="_blank" rel="noopener">${esc(r.key)}</a></td>
  <td>${esc(r.title)}<div class="meta"><span class="tag">${esc(r.module)}</span><span class="tag t">${esc(r.type)}</span></div></td>
  <td><span class="pill ${toneOf(r.status)}">${esc(r.status)}</span></td>
</tr>`,
    )
    .join('\n');

  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>QAlity Cycle Overview</title>
<style>
:root{--bg:#f6f7f9;--card:#fff;--ink:#1d2330;--muted:#6b7385;--line:#e4e7ee;--accent:#0f8b8d;--accentbg:#e3f4f4;--ok:#1f8a5b;--warn:#b7791f;--bad:#c2410c;--info:#2f6fde;--okbg:#e6f4ec;--warnbg:#fdf3e1;--badbg:#fdebe3;--infobg:#e7effc}
@media (prefers-color-scheme:dark){:root{--bg:#12151c;--card:#1a1f29;--ink:#e7eaf0;--muted:#98a1b3;--line:#2a3140;--accent:#3cc4c6;--accentbg:#13302f;--ok:#4cc38a;--warn:#e3b04b;--bad:#f0855a;--info:#6f9ef0;--okbg:#173327;--warnbg:#3a2f17;--badbg:#3d2219;--infobg:#1b2740}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:0 16px 48px}
header{border-top:4px solid var(--accent);background:var(--card);border-bottom:1px solid var(--line);margin:0 -16px 20px;padding:20px 16px}
header .in{max-width:1148px;margin:0 auto;display:flex;flex-wrap:wrap;gap:8px 16px;align-items:flex-end;justify-content:space-between}
.eyebrow{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--accent);font-weight:650}
h1{font-size:22px;margin:2px 0 0}.sub{color:var(--muted);font-size:13px}
.badge{display:inline-block;padding:2px 9px;border-radius:99px;font-size:12px;font-weight:600;background:var(--accentbg);color:var(--accent)}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}
h2{font-size:13px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);margin:0 0 10px;font-weight:600}
.hero{display:grid;grid-template-columns:minmax(280px,1.3fr) 1fr 1fr;gap:12px;margin-bottom:12px}
.ringbox{display:flex;gap:18px;align-items:center}
.ring{width:140px;height:140px;flex:none;transform:rotate(-90deg)}
.ring .track{stroke:var(--line)}.seg.ok{stroke:var(--ok)}.seg.warn{stroke:var(--warn)}.seg.bad{stroke:var(--bad)}.seg.info{stroke:var(--info)}.seg.muted{stroke:var(--muted)}
.ringwrap{position:relative;width:140px;height:140px;flex:none}
.ringlabel{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}
.ringlabel b{font-size:26px;font-weight:650;line-height:1}.ringlabel span{font-size:12px;color:var(--muted)}
.legend{list-style:none;margin:0;padding:0;display:grid;gap:6px;font-size:13px}
.legend li{display:flex;align-items:center;gap:8px}.legend b{margin-left:auto;font-weight:600}
.dot{width:10px;height:10px;border-radius:3px;flex:none}.dot.ok{background:var(--ok)}.dot.warn{background:var(--warn)}.dot.bad{background:var(--bad)}.dot.info{background:var(--info)}.dot.muted{background:var(--muted)}
.k{font-size:26px;font-weight:650}.l{color:var(--muted);font-size:12.5px}
.stack{display:flex;height:10px;border-radius:99px;overflow:hidden;background:var(--line);margin:10px 0 8px}
.stack i{display:block;height:100%}.stack .me{background:var(--accent)}.stack .oth{background:var(--muted);opacity:.45}
.kv{display:flex;justify-content:space-between;font-size:12.5px;color:var(--muted);margin-top:4px}.kv b{color:var(--ink);font-weight:600}
.up{color:var(--ok);font-size:12.5px;font-weight:600}
svg.spark{width:100%;height:34px;margin-top:6px;color:var(--accent)}
.main{display:grid;grid-template-columns:320px 1fr;gap:12px;align-items:start}
.side{display:grid;gap:12px}
.mod{margin-bottom:10px}.mod:last-child{margin-bottom:0}
.mod .top{display:flex;justify-content:space-between;gap:8px;font-size:13px}.mod .top span{color:var(--muted);white-space:nowrap}
.mbar{display:flex;height:6px;border-radius:99px;overflow:hidden;background:var(--line);margin-top:4px}
.mbar i{display:block;height:100%}.mbar .p{background:var(--ok)}.mbar .o{background:var(--warn)}
.chips{display:flex;flex-wrap:wrap;gap:6px}
.chip{padding:3px 10px;border-radius:99px;border:1px solid var(--line);font-size:12.5px}.chip b{font-weight:600;margin-left:4px}
.att{border-left:3px solid var(--warn)}
.att ul{list-style:none;margin:0;padding:0;display:grid;gap:8px}
.att li{font-size:13px}.att .meta{margin-top:2px}
.tools{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:0 0 12px}
.tools input,.tools select{padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:var(--card);color:var(--ink);font:inherit}
.tools input{flex:1;min-width:180px}
.seg-ctl{display:inline-flex;border:1px solid var(--line);border-radius:8px;overflow:hidden}
.seg-ctl button{padding:7px 12px;border:0;border-right:1px solid var(--line);background:var(--card);color:var(--ink);cursor:pointer;font:inherit;font-size:13px}
.seg-ctl button:last-child{border-right:0}.seg-ctl button.on{background:var(--accent);color:#fff}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden}
th,td{padding:10px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);background:var(--bg)}
tr:last-child td{border-bottom:0}td.key{white-space:nowrap}
a{color:var(--accent);text-decoration:none}a:hover{text-decoration:underline}
.meta,.muted{color:var(--muted);font-size:12.5px}
.tag{display:inline-block;margin:4px 6px 0 0;padding:0 7px;border-radius:5px;background:var(--bg);border:1px solid var(--line);font-size:11.5px;color:var(--muted)}
.tag.t{background:var(--accentbg);border-color:transparent;color:var(--accent)}
.pill{display:inline-block;padding:2px 9px;border-radius:99px;font-size:12px;font-weight:600;white-space:nowrap}
.pill.ok{background:var(--okbg);color:var(--ok)}.pill.warn{background:var(--warnbg);color:var(--warn)}.pill.bad{background:var(--badbg);color:var(--bad)}.pill.info{background:var(--infobg);color:var(--info)}.pill.muted{background:var(--line);color:var(--muted)}
.count{color:var(--muted);font-size:12.5px;margin-left:auto}
@media (max-width:980px){.hero{grid-template-columns:1fr 1fr}.hero .ringcard{grid-column:1/-1}.main{grid-template-columns:1fr}}
@media (max-width:560px){.hero{grid-template-columns:1fr}.ringbox{flex-direction:column;align-items:flex-start}th,td{padding:8px}}
</style></head><body><div class="wrap">
<header><div class="in">
 <div><div class="eyebrow">QAlity Plus · Test cycle</div><h1>${esc(d.cycle.name)}</h1>
 <div class="sub">Executions assigned to ${esc(d.assignee)} · Generated ${esc(d.generatedAt.toLocaleString())}</div></div>
 <div><span class="badge">${d.cycle.isClosed ? 'Closed' : 'Open'}</span> &nbsp;<a href="${esc(d.cycle.url)}" target="_blank" rel="noopener">Open cycle ${d.cycle.id} ↗</a></div>
</div></header>

<section class="hero">
 <div class="card ringcard"><h2>My executions</h2><div class="ringbox">
  <div class="ringwrap"><svg class="ring" viewBox="0 0 140 140" aria-hidden="true"><circle class="track" r="${R}" cx="70" cy="70" fill="none" stroke-width="16"/>${ring}</svg>
   <div class="ringlabel"><b>${pct(passed)}%</b><span>passed</span></div></div>
  <ul class="legend">${statuses.map(([name, n]) => `<li><span class="dot ${toneOf(name)}"></span>${esc(name)}<b>${n}</b></li>`).join('')}
   <li class="muted" style="border-top:1px solid var(--line);padding-top:6px">Total assigned<b>${total}</b></li></ul>
 </div></div>
 <div class="card"><h2>Execution progress</h2><div class="k">${pct(executed)}%</div>
  <div class="l">${executed} of ${total} executed${delta > 0 ? ` · <span class="up">+${delta} since last run</span>` : ''}</div>
  ${hist.length > 1 ? `<svg class="spark" viewBox="0 0 100 32" preserveAspectRatio="none"><polyline fill="none" stroke="currentColor" stroke-width="1.5" points="${sparkPts}"/></svg><div class="meta">Executed % over the last ${hist.length} runs</div>` : '<div class="meta" style="margin-top:8px">Trend appears after the next run.</div>'}
  <div class="kv"><span>Failed</span><b>${failed}</b></div>
 </div>
 <div class="card"><h2>Share of cycle</h2><div class="k">${pct(total, d.cycleTotal)}%</div>
  <div class="l">${total} of ${d.cycleTotal} cases in this cycle</div>
  <div class="stack" title="Mine / others / unassigned"><i class="me" style="width:${pct(total, d.cycleTotal)}%"></i><i class="oth" style="width:${pct(others, d.cycleTotal)}%"></i></div>
  <div class="kv"><span>Mine</span><b>${total}</b></div><div class="kv"><span>Other testers</span><b>${others}</b></div><div class="kv"><span>Unassigned</span><b>${d.unassigned}</b></div>
 </div>
</section>

<section class="main">
 <aside class="side">
  ${attention.length ? `<div class="card att"><h2>Needs attention · ${attention.length}</h2><ul>${attention
    .map((r) => `<li><a href="${esc(`${d.jiraBase}/browse/${r.key}`)}" target="_blank" rel="noopener">${esc(r.key)}</a> <span class="pill ${toneOf(r.status)}">${esc(r.status)}</span><div class="meta">${esc(r.title)}</div></li>`)
    .join('')}</ul></div>` : `<div class="card"><h2>Needs attention</h2><div class="muted">Nothing open — every case is passed.</div></div>`}
  <div class="card"><h2>By module</h2>${modules
    .map(([name, g]) => `<div class="mod"><div class="top"><div>${esc(name)}</div><span>${g.passed}/${g.total}</span></div>
     <div class="mbar" style="width:${Math.max((g.total / maxModule) * 100, 8)}%"><i class="p" style="width:${pct(g.passed, g.total)}%"></i><i class="o" style="width:${pct(g.open, g.total)}%"></i></div></div>`)
    .join('')}</div>
  <div class="card"><h2>By test type</h2><div class="chips">${types
    .map(([name, g]) => `<span class="chip" title="${g.passed} passed, ${g.open} open">${esc(name)}<b>${g.total}</b></span>`)
    .join('')}</div></div>
 </aside>

 <div>
  <div class="tools">
   <input id="q" placeholder="Search key or summary…" aria-label="Search">
   <select id="mod" aria-label="Module"><option value="">All modules</option>${modules.map(([name]) => `<option>${esc(name)}</option>`).join('')}</select>
   <div class="seg-ctl"><button class="on" data-f="all">All ${total}</button>${statuses
     .map(([name, n]) => `<button data-f="${slug(name)}">${esc(name)} ${n}</button>`)
     .join('')}</div>
  </div>
  <table><thead><tr><th>Key</th><th>Test case</th><th>Status</th></tr></thead><tbody>${tr}</tbody></table>
  <div class="meta" id="shown" style="margin-top:8px"></div>
 </div>
</section>
</div>
<script>
const q=document.getElementById('q'),mod=document.getElementById('mod'),shown=document.getElementById('shown');let f='all';
function apply(){const t=q.value.toLowerCase(),m=mod.value;let n=0;document.querySelectorAll('tbody tr').forEach(r=>{const ok=(f==='all'||r.dataset.status===f)&&(!m||r.dataset.module===m)&&r.dataset.text.includes(t);r.style.display=ok?'':'none';if(ok)n++});shown.textContent='Showing '+n+' of ${total}'}
q.addEventListener('input',apply);mod.addEventListener('change',apply);
document.querySelectorAll('[data-f]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-f]').forEach(x=>x.classList.remove('on'));b.classList.add('on');f=b.dataset.f;apply()}));
apply();
</script></body></html>`;
}
